# :warning: DEPRECATED

This repository is no longer maintained. Use the official Gradio [Model3D component](https://www.gradio.app/docs/model3d) for Gaussian Splatting.
