import type { FileData } from "@gradio/client";
import * as SPLAT from "gsplat";

export const create_renderer = (
    canvas: HTMLCanvasElement,
    value: FileData | null,
    scene: SPLAT.Scene,
    camera: SPLAT.Camera,
    renderer: SPLAT.WebGLRenderer | null,
    zoom_speed: number,
    pan_speed: number,
    render_loop_id: number | null
) => {
    if (render_loop_id) {
        cancelAnimationFrame(render_loop_id);
        render_loop_id = null;
    }
    if (renderer) {
        renderer.dispose();
    }

    renderer = new SPLAT.WebGLRenderer(canvas);
    const controls = new SPLAT.OrbitControls(camera, canvas);
    controls.zoomSpeed = zoom_speed;
    controls.panSpeed = pan_speed;

    if (!value) {
        return { renderer, render_loop_id };
    }

    let loading = false;

    const frame = () => {
        if (loading) {
            requestAnimationFrame(frame);
            return;
        }

        controls.update();
        renderer!.render(scene, camera);

        requestAnimationFrame(frame);
    };

    const load = async () => {
        loading = true;
        await SPLAT.Loader.LoadAsync(value.url!, scene, (progress) => {
            // TODO: loading bar
        });
        loading = false;
    };

    render_loop_id = requestAnimationFrame(frame);
    load();

    return { renderer, render_loop_id };
};
